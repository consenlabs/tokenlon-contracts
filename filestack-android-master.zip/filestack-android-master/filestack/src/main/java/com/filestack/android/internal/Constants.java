package com.filestack.android.internal;

import static android.app.Activity.RESULT_FIRST_USER;

public class Constants {
    static final int REQUEST_MEDIA_CAPTURE = RESULT_FIRST_USER;
}
