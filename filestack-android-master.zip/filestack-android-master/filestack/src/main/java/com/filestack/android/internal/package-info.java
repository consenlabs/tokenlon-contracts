/** Internal API. Not covered under versioning. */
package com.filestack.android.internal;