/** Filestack is an easy API for file uploading, conversion, and delivery. */
package com.filestack.android;